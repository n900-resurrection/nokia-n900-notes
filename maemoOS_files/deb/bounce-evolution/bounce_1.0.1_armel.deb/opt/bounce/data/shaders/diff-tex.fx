technique Default
{
	pass P0
	{
		VertexShader = vertexShaders/diff-tex.vs;
		PixelShader = pixelShaders/diff-tex.ps;
		
		#ifdef ENABLE_TWOSIDED
			EnableCulling = FALSE;
		#endif
		
		#ifdef ENABLE_ADDITIVE
			EnableBlending = TRUE;
			BlendFuncSrc = ONE;
			BlendFuncDst = ONE;
		#endif
		
		#ifdef ENABLE_MULTIPLICATIVE
			EnableBlending = TRUE;
			BlendFuncSrc = DST_COLOR;
			BlendFuncDst = ZERO;
		#endif
		
		#ifdef ENABLE_ALPHA_BLENDING
			EnableDepthMask = FALSE;
			EnableBlending = TRUE;
			BlendFuncSrc = SRC_ALPHA;
			BlendFuncDst = ONE_MINUS_SRC_ALPHA;
		#endif
		
		#ifdef DISABLE_DEPTH_TEST
			EnableDepthTest = FALSE;
		#endif
	}
}

#ifdef ENABLE_REFLECTED

technique Reflected
{
	pass P0
	{
		VertexShader = vertexShaders/diff-tex.vs;
		PixelShader = pixelShaders/diff-tex.ps;
		
		#ifdef ENABLE_TWOSIDED
			EnableCulling = FALSE;
		#endif
		
		#ifdef ENABLE_ADDITIVE
			EnableBlending = TRUE;
			BlendFuncSrc = ONE;
			BlendFuncDst = ONE;
		#endif
		
		#ifdef ENABLE_MULTIPLICATIVE
			EnableBlending = TRUE;
			BlendFuncSrc = DST_COLOR;
			BlendFuncDst = ZERO;
		#endif
		
		#ifdef ENABLE_ALPHA_BLENDING
			EnableDepthMask = FALSE;
			EnableBlending = TRUE;
			BlendFuncSrc = SRC_ALPHA;
			BlendFuncDst = ONE_MINUS_SRC_ALPHA;
		#endif
		
		#ifdef ENABLE_PREMULT_ALPHA_BLENDING
			EnableDepthMask = FALSE;
			EnableBlending = TRUE;
			BlendFuncSrc = ONE;
			BlendFuncDst = ONE_MINUS_SRC_ALPHA;
		#endif
		
		#ifdef DISABLE_DEPTH_TEST
			EnableDepthTest = FALSE;
		#endif
	}
}

#endif
