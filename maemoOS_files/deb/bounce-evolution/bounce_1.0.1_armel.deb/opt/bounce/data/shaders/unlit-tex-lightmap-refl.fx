#define DISABLE_LIGHTING
#define ENABLE_LIGHTMAP
#define ENABLE_REFLECTED

#include "diff-tex.fx"