#define ENABLE_MULTIPLICATIVE

#include "pp.fx"