#define DISABLE_LIGHTING
#define ENABLE_MOVEUV
#define ENABLE_REFLECTED

#include "diff-tex.fx"