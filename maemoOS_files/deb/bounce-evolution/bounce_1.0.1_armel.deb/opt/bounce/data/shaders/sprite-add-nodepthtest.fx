#define ENABLE_ADDITIVE
#define DISABLE_DEPTH_TEST

priority = -1;

#include "pp.fx"