#define DISABLE_LIGHTING
#define DISABLE_FOG
#define ENABLE_ALPHA_BLENDING

priority = -1;
sort = BACKTOFRONT;

#include "diff-tex.fx"