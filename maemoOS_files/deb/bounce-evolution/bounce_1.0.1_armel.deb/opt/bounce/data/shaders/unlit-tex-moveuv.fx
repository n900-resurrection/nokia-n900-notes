#define DISABLE_LIGHTING
#define ENABLE_MOVEUV

#include "diff-tex.fx"