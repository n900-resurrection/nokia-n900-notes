#define ENABLE_ADDITIVE

priority = -1;

#include "pp.fx"