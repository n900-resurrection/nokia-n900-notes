#define DISABLE_LIGHTING
#define DISABLE_FOG

#include "diff-tex.fx"