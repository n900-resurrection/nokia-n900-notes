#define DISABLE_LIGHTING

#include "diff-tex.fx"