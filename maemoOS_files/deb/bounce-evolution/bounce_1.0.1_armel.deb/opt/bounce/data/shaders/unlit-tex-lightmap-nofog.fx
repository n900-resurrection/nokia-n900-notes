#define DISABLE_LIGHTING
#define ENABLE_LIGHTMAP
#define DISABLE_FOG

#include "diff-tex.fx"