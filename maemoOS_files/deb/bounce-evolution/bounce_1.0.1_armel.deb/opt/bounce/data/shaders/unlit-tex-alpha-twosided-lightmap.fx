#define DISABLE_LIGHTING
#define ENABLE_ALPHA_BLENDING
#define ENABLE_TWOSIDED
#define ENABLE_LIGHTMAP

priority = -1;
sort = BACKTOFRONT;

#include "diff-tex.fx"