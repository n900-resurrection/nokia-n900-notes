#define DISABLE_LIGHTING
#define ENABLE_ALPHA_BLENDING
#define MULTIPLY_BY_DIFFUSEC

priority = -1;
sort = BACKTOFRONT;

#include "diff-tex.fx"