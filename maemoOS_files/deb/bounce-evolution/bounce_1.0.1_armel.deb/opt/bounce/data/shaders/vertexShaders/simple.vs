#include "../commons/attributes.sh"
#include "../commons/uniforms.sh"
#include "../commons/varyings.sh"

void main()
{
	// Transform coordinates to screen space
	gl_Position = TOTALTM * vec4(DT_POSITION, 1);
}
