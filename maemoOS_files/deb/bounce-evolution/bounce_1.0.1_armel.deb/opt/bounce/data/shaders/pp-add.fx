#define DISABLE_DEPTH_TEST
#define ENABLE_ADDITIVE

#include "pp.fx"