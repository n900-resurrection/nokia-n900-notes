#define ENABLE_REFLECTED
#define ENABLE_SHININESS_MAP

#include "diff-tex.fx"