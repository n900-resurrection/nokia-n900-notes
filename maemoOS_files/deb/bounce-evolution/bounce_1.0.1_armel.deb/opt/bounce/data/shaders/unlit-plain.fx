#define DISABLE_LIGHTING
#define DISABLE_TEXTURE

#include "diff-tex.fx"