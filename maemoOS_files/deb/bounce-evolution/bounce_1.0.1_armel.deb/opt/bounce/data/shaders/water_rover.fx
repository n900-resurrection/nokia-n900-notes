#define ENABLE_WNORMALMAP
#define DISABLE_TEXTURE
#define ENABLE_PLANE_REFLECTION
#define DISABLE_AMBIENT
#define DISABLE_DIFFUSE
#define DISABLE_SPECULAR

technique Default
{
	pass P0
	{
		VertexShader = vertexShaders/diff-tex.vs;
		PixelShader = pixelShaders/diff-tex.ps;
	}
}

technique Water
{
	pass P0
	{
		VertexShader = vertexShaders/diff-tex.vs;
		PixelShader = pixelShaders/diff-tex.ps;
	}
}

technique WriteDepth
{
	pass P0
	{
		DepthFunc = ALWAYS;
		VertexShader = vertexShaders/simple.vs;
		PixelShader = pixelShaders/simple.ps;
	}
}