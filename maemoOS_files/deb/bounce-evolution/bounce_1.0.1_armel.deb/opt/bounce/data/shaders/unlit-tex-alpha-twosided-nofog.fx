#define DISABLE_LIGHTING
#define ENABLE_ALPHA_BLENDING
#define ENABLE_TWOSIDED
#define DISABLE_FOG

priority = -1;
sort = BACKTOFRONT;

#include "diff-tex.fx"