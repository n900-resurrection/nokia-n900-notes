#define DISABLE_LIGHTING
#define ENABLE_LIGHTMAP

#include "diff-tex.fx"