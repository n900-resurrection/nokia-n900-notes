#define DISABLE_DEPTH_TEST
#define BLUR_1D

#include "pp.fx"