#define DISABLE_LIGHTING
#define ENABLE_ALPHA_BLENDING
#define ENABLE_TWOSIDED
#define ENABLE_LIGHTMAP
#define ENABLE_REFLECTED

priority = -1;
sort = BACKTOFRONT;

#include "diff-tex.fx"