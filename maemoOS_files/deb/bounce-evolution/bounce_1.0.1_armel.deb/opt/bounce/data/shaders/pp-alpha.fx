#define DISABLE_DEPTH_TEST
#define ENABLE_PREMULT_ALPHA_BLENDING
#define ENABLE_ALPHA_FACTOR

priority = -3;

#include "pp.fx"