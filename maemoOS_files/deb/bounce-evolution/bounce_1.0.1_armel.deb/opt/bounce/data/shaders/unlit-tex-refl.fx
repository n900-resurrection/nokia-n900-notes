#define DISABLE_LIGHTING
#define ENABLE_REFLECTED

#include "diff-tex.fx"