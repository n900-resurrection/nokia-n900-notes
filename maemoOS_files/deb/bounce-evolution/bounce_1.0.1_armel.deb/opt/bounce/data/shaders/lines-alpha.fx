#define DISABLE_LIGHTING
#define DISABLE_TEXTURE
#define DISABLE_FOG
#define ENABLE_VERTEXCOLOR
#define ENABLE_ALPHA_BLENDING
#define DISABLE_DEPTH_TEST

priority = -3;

#include "diff-tex.fx"