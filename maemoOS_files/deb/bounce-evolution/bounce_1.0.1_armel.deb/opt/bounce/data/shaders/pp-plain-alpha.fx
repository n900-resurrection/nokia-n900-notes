#define DISABLE_DEPTH_TEST
#define ENABLE_ALPHA_BLENDING
#define DISABLE_TEXTURE

#include "pp.fx"