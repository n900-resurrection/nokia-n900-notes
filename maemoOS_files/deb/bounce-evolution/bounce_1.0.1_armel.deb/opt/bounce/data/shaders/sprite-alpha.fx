#define ENABLE_ALPHA_BLENDING

priority = -1;

#include "pp.fx"