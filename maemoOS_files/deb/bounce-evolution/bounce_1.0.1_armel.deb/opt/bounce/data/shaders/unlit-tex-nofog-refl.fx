#define DISABLE_LIGHTING
#define DISABLE_FOG
#define ENABLE_REFLECTED

#include "diff-tex.fx"