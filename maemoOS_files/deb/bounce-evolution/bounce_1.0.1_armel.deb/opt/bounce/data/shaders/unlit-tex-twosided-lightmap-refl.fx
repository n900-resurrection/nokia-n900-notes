#define DISABLE_LIGHTING
#define ENABLE_LIGHTMAP
#define ENABLE_REFLECTED
#define ENABLE_TWOSIDED

#include "diff-tex.fx"